﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.IO;
using MvcDemoApp.Models;
using MvcDemoApp.DatabaseLayer;

namespace MvcDemoApp.Controllers
{
    public class DocumentController : Controller
    {
        public ActionResult Index()
        {
            DocumentSelector DocSelect = new DocumentSelector();
            ViewBag.OccuCode = new SelectList(DocSelect.getddOccuCode());
            return View("Index",DocSelect);
        }

        public ActionResult GridResult2(string ddValue)
        {
            //ddValue = string.Empty;
            //ddValue = Request.Form["OccuCode"].ToString();
            TempData["dropVal"] = ddValue;
            TempData.Keep("dropVal");
            List<DocumentSelector> gridMap = new List<DocumentSelector>();
            DataSet ds = new DataSet();
            ds = DatabaseLayer.DatabaseCon.getGridMapping(ddValue);
            
            foreach(DataRow dr in ds.Tables[0].Rows)
            {
                gridMap.Add(new DocumentSelector
                {
                    DocumentName = dr["DocName"].ToString(),
                    OccupationName = dr["OcuupName"].ToString()
                });
            }
            return PartialView("_GridResult", gridMap);
        }

        [HttpPost]
        public ActionResult FileUpload(FormCollection form)
        {
            string DropDownVal = TempData["dropVal"].ToString();
            TempData.Keep("dropVal");
            string Message = string.Empty;
            string UserName = (string)(Session["UserName"]);
            
            if (Request.Files.Count > 0)
            {
                try
                {
                    //  Get all files from Request object  
                    HttpFileCollectionBase files = Request.Files;
                    for (int i = 0; i < files.Count; i++)
                    {
                        //string path = AppDomain.CurrentDomain.BaseDirectory + "Uploads/";  
                        //string filename = Path.GetFileName(Request.Files[i].FileName);  

                        HttpPostedFileBase file = files[i];
                        string fname;
                        string Imgname;
                        // Checking for Internet Explorer  
                        if (Request.Browser.Browser.ToUpper() == "IE" || Request.Browser.Browser.ToUpper() == "INTERNETEXPLORER")
                        {
                            string[] testfiles = file.FileName.Split(new char[] { '\\' });
                            Imgname = testfiles[testfiles.Length - 1];
                        }
                        else
                        {
                            Imgname = file.FileName;
                        }

                        // Get the complete folder path and store the file inside it.  
                        //fname = Path.Combine(Server.MapPath("~/" + DropDownVal + "/Files/"), fname);
                        string PathName = Server.MapPath(@"~/Files/" + DropDownVal + "/" + UserName);
                        Directory.CreateDirectory(PathName);
                        string FileExtension = Path.GetExtension(Imgname);

                        if (FileExtension == ".jpeg" || FileExtension == ".png" || FileExtension == ".jpg")
                        {
                            fname = Path.Combine(PathName, Imgname);
                            if (System.IO.File.Exists(fname))
                            {
                                return Json(new { Message = "File already exists!" });
                            }
                            else
                            {
                                file.SaveAs(fname);
                                DocumentSelector DocSel = new DocumentSelector();
                                DocSel.UploadFileInsert(UserName, Imgname, DropDownVal, PathName);
                                //var Status = form.GetValues("GridSubmit");
                            }
                        }
                        else
                        {
                            return Json(new { Message = "ExtensionE" });
                        }
                    }
                    // Returns message that successfully uploaded  
                    return Json(new { Message = "Success"});
                }
                catch (Exception)
                {
                    return Json(new { Message = "Error" });
                }
            }
            else
            {
                return Json(new { Message = "Nofiles" });
            }  

            //return RedirectToAction("GridResult2", "Document", new { ddValue = DropDownVal });
        }
    }
}
