﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcDemoApp.Models;


namespace MvcDemoApp.Controllers
{
    public class FirstTimeLoginController : Controller
    {
        //
        // GET: /FirstTimeLogin/

        public ActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public ActionResult Index(FormCollection collection)
        {
            FirstTimeLogin FT = new FirstTimeLogin();
            FT.FirstName = collection["FirstName"];
            FT.LastName =  collection["LastName"];
            FT.DateOfBirth = Convert.ToDateTime(collection["DateOfBirth"]);
            FT.NewPassword =   collection["NewPassword"];
            FT.ConfirmPassword = collection["ConfirmPassword"];
            FT.SecurityQuestion_1 = collection["SecurityQuestion_1"];
            FT.SecurityQuestion_2 =  collection["SecurityQuestion_2"];
            
            return RedirectToAction("Index", "Document");
        }

        //
        // GET: /FirstTimeLogin/Details/5

        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /FirstTimeLogin/Create

        public ActionResult Create()
        {
            return View();
        }

        //
        // POST: /FirstTimeLogin/Create

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here
                return RedirectToAction("Index", "Document");
            }
            catch
            {
                return View();
            }
        }
    }
}
