﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Drawing;
using System.Web.Mvc;
using MvcDemoApp.Models;
using MvcDemoApp.DatabaseLayer;
 

namespace MvcDemoApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            Session.Abandon();
            Session.Clear();
            return View();
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(FormCollection frmCollect)
        {
            EmployeeLogin employee = new EmployeeLogin();
            employee._Username = frmCollect["Username"];
            employee._password = frmCollect["Password"];

            employee.ValidateLogin(employee._Username,employee._password);

            if (DatabaseCon.Result == "Success")
            {
                DatabaseCon.FetchLoginDetails(employee._Username);
                if (DatabaseCon.PreviousLoginDt != null && DatabaseCon.PreviousLoginDt != "")
                {
                    Session["UserName"] = frmCollect["Username"];
                    ViewBag.LoginMsg = "Login Successful!";
                    return RedirectToAction("Index", "Document");
                }               
                else
                {
                    Session["UserName"] = frmCollect["Username"];
                    return RedirectToAction("Index", "FirstTimeLogin");
                }
            }
            else if (DatabaseCon.Result == "Locked")
            {
                ViewBag.LoginMsg = "Your Account has been Locked! Please contact Admin Support.";
            }
            else
            {
                ViewBag.LoginMsg = "Login Failed";
                //RedirectToAction("Create");
            }
            return View();
        }

    }
}
