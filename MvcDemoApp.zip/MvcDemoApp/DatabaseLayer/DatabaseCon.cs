﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using MvcDemoApp.Models;

namespace MvcDemoApp.DatabaseLayer
{
    public class DatabaseCon
    {
        private static string result = "";
        private static string message = "";
        private static Guid Userid;
        private static string PreviousLoginDT;
        private static string AcctActivate;

        public static string Result { get { return result; } set { result = value; } }
        public static string Message { get { return message; } set { message = value; } }
        public static Guid UserID { get { return Userid; } set { Userid = value; } }
        public static string PreviousLoginDt { get { return PreviousLoginDT; } set { PreviousLoginDT = value; } }
        public static string AccounttActivate { get { return AcctActivate; } set { AcctActivate = value; } }

        public static string ConnectionDB()
        {
            return ConfigurationManager.ConnectionStrings["AccountConnection"].ConnectionString;
        }

        public static void LoginValidate(string UserName, string Password)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(ConnectionDB()))
                {
                    using (SqlCommand cmd = new SqlCommand("Emplogin", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@Usename", UserName.ToString());
                        cmd.Parameters.AddWithValue("@password", Password.ToString());

                        SqlParameter outParam = new SqlParameter();
                        outParam.ParameterName = "@OutMessage";
                        outParam.DbType = DbType.Int32;
                        outParam.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(outParam);


                        conn.Open();
                        //cmd.ExecuteNonQuery();                     
                        int userCount = (Int32)cmd.ExecuteScalar();
                        string Message = cmd.Parameters["@OutMessage"].Value.ToString();
                        if (userCount == 1 && Message == "0")
                        {
                            result = "Success";
                        }
                        else if (Message == "1")
                        {
                            result = "Locked";
                        }
                        else
                        {
                            result = "Failed";
                        }
                        conn.Close();

                    }

                }

            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }

        public static List<string> GetOccupCode()
        {
            List<string> result = new List<string>();

            using (SqlConnection conn = new SqlConnection(DatabaseCon.ConnectionDB()))
            {
                using (SqlCommand cmd = new SqlCommand("dbo.GetOccupation", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();

                    using (SqlDataReader Dreader = cmd.ExecuteReader())
                    {
                        while (Dreader.Read())
                        {
                            DocumentSelector docSel = new DocumentSelector();
                            docSel.OccupationCd = Dreader.GetString(0);
                            result.Add(docSel.OccupationCd);
                        }
                        Dreader.Close();
                    }
                    conn.Close();
                }

            }
            return result;
        }


        public static DataSet getGridMapping(string OccuCode)
        {
            using (SqlConnection conn = new SqlConnection(ConnectionDB()))
            {
                using (SqlCommand cmd = new SqlCommand("getDocMapping", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@OccuCD", OccuCode.ToString());
                    conn.Open();

                    SqlDataAdapter DA = new SqlDataAdapter();
                    DA.SelectCommand = cmd;
                    DataSet ds = new DataSet();
                    DA.Fill(ds);
                    return ds;
                }

            }
        }

        public static void InsertUploadFile(string UserName, string ImageName , string DocCode, string path)
        {
            try
            {   
                using (SqlConnection conn = new SqlConnection(DatabaseCon.ConnectionDB()))
                {
                    using (SqlCommand cmd = new SqlCommand("InsertUploadFile",conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@DocCode", DocCode.ToString());
                        cmd.Parameters.AddWithValue("@ImageName", ImageName.ToString());
                        cmd.Parameters.AddWithValue("@Destination", path.ToString());
                        cmd.Parameters.AddWithValue("@Upload_By", UserName.ToString());
                        cmd.Parameters.AddWithValue("@Upload_date", DateTime.Now);
                        cmd.Parameters.Add("@Message", SqlDbType.NVarChar, 1000);
                        cmd.Parameters["@Message"].Direction = ParameterDirection.Output;
                        conn.Open();
                        
                        cmd.ExecuteNonQuery();
                        conn.Close();

                        message = cmd.Parameters["@Message"].Value.ToString();
                    }
                }
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
        }

        public static void FetchLoginDetails(string UserName)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(DatabaseCon.ConnectionDB()))
                {
                    using (SqlCommand cmd = new SqlCommand("dbo.FetchLoginDetails", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        conn.Open();

                        cmd.Parameters.AddWithValue("@Usename", UserName.ToString());

                        SqlParameter outParam1 = new SqlParameter();
                        outParam1.ParameterName = "@ID";
                        outParam1.DbType = DbType.Guid;
                        outParam1.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(outParam1);

                        SqlParameter outParam2 = new SqlParameter();
                        outParam2.ParameterName = "@Dt_PreviousLogin";
                        outParam2.DbType = DbType.DateTime;
                        outParam2.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(outParam2);

                        SqlParameter outParam3 = new SqlParameter("@AccountActive", SqlDbType.Char, 5);
                        outParam3.Direction = ParameterDirection.Output;
                        cmd.Parameters.Add(outParam3);

                        cmd.ExecuteNonQuery();                        

                        string UserID = cmd.Parameters["@ID"].Value.ToString();
                        PreviousLoginDt = cmd.Parameters["@Dt_PreviousLogin"].Value.ToString();
                        AccounttActivate = cmd.Parameters["@AccountActive"].Value.ToString();
                        conn.Close();
                    }
                }
            }
            catch
            {

            }
        }
    }
}