/****** Object:  StoredProcedure [dbo].[Emplogin]    Script Date: 8/5/2016 5:59:58 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER procedure [dbo].[Emplogin]
(
@Usename Varchar (50),
@password varchar (50),
@OutMessage NVarchar(10) OUTPUT
)
as
Begin
	DECLARE @LoginAttempt varchar(100)
	DECLARE @UserCount nchar(10)
	Select COUNT(*) from [login] where username= @Usename and pwd= @password
	
	Select @LoginAttempt = ISNULL(MAX(LoginAttempt),0) from dbo.login where username= @Usename
	if(@LoginAttempt = '3')
	SET @OutMessage = '1'
	else
	SET @OutMessage = '0'
	if((Select COUNT(*) from [login] where username= @Usename and pwd= @password) = '1')
	UPDATE dbo.login set LoginAttempt = 0 , Dt_PreviousLogin = GETDATE() where username= @Usename
	else
	UPDATE dbo.login set LoginAttempt = @LoginAttempt + 1 where username= @Usename
End;
