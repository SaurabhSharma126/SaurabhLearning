/****** Object:  StoredProcedure [dbo].[FetchLoginDetails]    Script Date: 8/5/2016 6:00:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[FetchLoginDetails]
@Usename nvarchar(50),  
@ID uniqueidentifier OUTPUT,
@Dt_PreviousLogin  DATETIME OUTPUT
AS    
Begin
    SET NOCOUNT ON;  
    SELECT @ID = [user_id], @Dt_PreviousLogin = Dt_PreviousLogin 
    FROM dbo.[login] 
    WHERE username = @Usename
	AND DOB is not null
End

GO

