USE [AccountOpenDB]
GO

/****** Object:  StoredProcedure [dbo].[InsertUploadFile]    Script Date: 7/21/2016 4:26:31 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[InsertUploadFile]
       @DocCode              VARCHAR(20), 
       @ImageName            VARCHAR(100), 
       @Destination          VARCHAR(250), 
       @Upload_date          DATETIME, 
       @Upload_By            VARCHAR(100)
AS 
BEGIN 
     SET NOCOUNT ON 
     INSERT INTO [dbo].[UploadFile](ID,DocCode,ImageName,Destination,Upload_date,Uploaded_By) 
     VALUES (NEWID(),@DocCode,@ImageName,@Destination,SYSDATETIME(),@Upload_By);
END 

GO

