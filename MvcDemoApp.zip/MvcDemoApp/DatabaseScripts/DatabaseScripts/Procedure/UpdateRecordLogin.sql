/****** Object:  StoredProcedure [dbo].[UpdatePassword]    Script Date: 8/5/2016 6:01:27 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER PROCEDURE [dbo].[UpdatePassword]
	   @ID uniqueIdentifier,
	   @FirstName varchar(200),
	   @LastName varchar(200),
	   @Security1 varchar(1000),
	   @security2 varchar(1000),
	   @DOB DATETIME,
	   @NewPass varchar(100),
	   @Message varchar(1000) OUTPUT
AS
BEGIN
 UPDATE dbo.login
 SET SecurityPhrase1 = @Security1,
 SecuirtyPhrase2 = @security2
 WHERE FirstName = @FirstName
 AND LastName = @LastName
 AND DOB = @DOB
 AND user_id = @ID
 
 if(@@ROWCOUNT > 0)
 SET @Message = 'success'
 else
 SET @Message = 'Fail'
END
