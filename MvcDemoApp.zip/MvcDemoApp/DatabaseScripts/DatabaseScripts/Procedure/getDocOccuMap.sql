USE [AccountOpenDB]
GO

/****** Object:  StoredProcedure [dbo].[getDocMapping]    Script Date: 7/21/2016 4:25:28 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[getDocMapping] 
	-- Add the parameters for the stored procedure here
	@OccuCD Varchar(20)
AS
Declare
@OccuName varchar(20)
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	Select @OccuName = 
	CASE @OccuCD
	WHEN 'GOVERNMENT' THEN 'GE'
	WHEN 'PRIVATE' THEN 'PE'
	WHEN 'SELF' THEN 'SE'
	WHEN 'STUDENT' THEN 'SD'
	WHEN 'GRADUATE' THEN 'GT'
	WHEN 'FOREIGNER' THEN'FR'
	ELSE NULL
	END
	
	Select doc.DocName , Occ.OcuupName from tbOccuDocMap Map
	inner join tbOccupationMst Occ
	on Occ.OccupCode = Map.OccuCd
	inner join tbDocumentMst Doc
	on Doc.DocCode = Map.DocCD
	where Map.Mandatory = 'Y'
	and Doc.DocStatus = 'A'
	and Map.OccuCD = @OccuName;
END



GO

