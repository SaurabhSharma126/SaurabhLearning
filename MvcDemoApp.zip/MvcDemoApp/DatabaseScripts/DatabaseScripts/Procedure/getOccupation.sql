USE [AccountOpenDB]
GO

/****** Object:  StoredProcedure [dbo].[GetOccupation]    Script Date: 7/21/2016 4:26:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[GetOccupation]
AS
BEGIN
SELECT OcuupName FROM tbOccupationMst
END;


GO

