
/****************** GE 
DECLARE
@ID uniqueidentifier
SET @ID = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID ,'GE','DL','Y');
END;

DECLARE
@ID1 uniqueidentifier
SET @ID1 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID1 ,'GE','AC','Y');
END;

DECLARE
@ID2 uniqueidentifier
SET @ID2 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID2 ,'GE','EB','Y');
END;

DECLARE
@ID3 uniqueidentifier
SET @ID3 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID3 ,'GE','EC','Y');
END;

DECLARE
@ID4 uniqueidentifier
SET @ID4 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID4 ,'GE','PAN','Y');
END;***************/

/***************** PE 
DECLARE
@ID uniqueidentifier
SET @ID = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID ,'PE','DL','Y');
END;

DECLARE
@ID1 uniqueidentifier
SET @ID1 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID1 ,'PE','AC','Y');
END;

DECLARE
@ID2 uniqueidentifier
SET @ID2 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID2 ,'PE','BS','Y');
END;

DECLARE
@ID3 uniqueidentifier
SET @ID3 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID3 ,'PE','OI','Y');
END;

DECLARE
@ID4 uniqueidentifier
SET @ID4 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID4 ,'PE','PAN','Y');
END;**********************/

/***************** SE
DECLARE
@ID uniqueidentifier
SET @ID = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID ,'SE','DL','Y');
END;

DECLARE
@ID1 uniqueidentifier
SET @ID1 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID1 ,'SE','AC','Y');
END;

DECLARE
@ID2 uniqueidentifier
SET @ID2 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID2 ,'SE','BS','Y');
END;

DECLARE
@ID3 uniqueidentifier
SET @ID3 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID3 ,'SE','PB','Y');
END;

DECLARE
@ID4 uniqueidentifier
SET @ID4 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID4 ,'SE','PAN','Y');
END;

DECLARE
@ID5 uniqueidentifier
SET @ID5 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID4 ,'SE','EB','Y');
END; *******************/

/**************** SD
DECLARE
@ID uniqueidentifier
SET @ID = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID ,'SD','BR','Y');
END;

DECLARE
@ID1 uniqueidentifier
SET @ID1 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID1 ,'SD','PCF','Y');
END;***************/

/**************** GT
DECLARE
@ID uniqueidentifier
SET @ID = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID ,'GT','DL','Y');
END;

DECLARE
@ID1 uniqueidentifier
SET @ID1 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID1 ,'GT','AC','Y');
END;

DECLARE
@ID2 uniqueidentifier
SET @ID2 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID2 ,'GT','SSC','Y');
END;

DECLARE
@ID3 uniqueidentifier
SET @ID3 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID3 ,'GT','PAN','Y');
END;

DECLARE
@ID4 uniqueidentifier
SET @ID4 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID4 ,'GT','EC','Y');
END;***********/

/**************** FR
DECLARE
@ID uniqueidentifier
SET @ID = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID ,'FR','PAN','Y');
END;

DECLARE
@ID1 uniqueidentifier
SET @ID1 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID1 ,'FR','BS','Y');
END;

DECLARE
@ID2 uniqueidentifier
SET @ID2 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID2 ,'FR','OI','Y');
END;

DECLARE
@ID3 uniqueidentifier
SET @ID3 = NEWID();
BEGIN
INSERT INTO tbOccuDocMap values(@ID3 ,'FR','PP','Y');
END;***************/
