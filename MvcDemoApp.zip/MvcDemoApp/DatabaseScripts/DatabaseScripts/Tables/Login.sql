/****** Object:  Table [dbo].[login]    Script Date: 8/5/2016 5:59:04 PM ******/
DROP TABLE [dbo].[login]
GO

/****** Object:  Table [dbo].[login]    Script Date: 8/5/2016 5:59:04 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[login](
	[user_id] [uniqueidentifier] NOT NULL DEFAULT (newid()),
	[username] [nvarchar](50) NOT NULL,
	[FirstName] [varchar](100) NOT NULL,
	[LastName] [varchar](100) NOT NULL,
	[pwd] [nvarchar](50) NOT NULL,
	[DOB] [datetime] NOT NULL,
	[Dt_PreviousLogin] [datetime] NULL,
	[LoginAttempt] [nchar](10) NULL DEFAULT ('0'),
	[AccountLocked] [nchar](10) NULL DEFAULT ('0'),
	[SecurityPhrase1] [varchar](100) NULL,
	[SecuirtyPhrase2] [varchar](100) NULL,
 CONSTRAINT [PK_login] PRIMARY KEY CLUSTERED 
(
	[user_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

