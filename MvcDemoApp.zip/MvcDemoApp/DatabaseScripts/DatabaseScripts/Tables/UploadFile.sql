CREATE TABLE UploadFile (
ID uniqueIdentifier DEFAULT NEWID() NOT NULL,
DocCode varchar(20) NOT NULL, 
ImageName varchar(100),
Destination varchar(250),
Upload_date DATE,
Uploaded_By varchar(100),
primary key(DocCode,ImageName)
);