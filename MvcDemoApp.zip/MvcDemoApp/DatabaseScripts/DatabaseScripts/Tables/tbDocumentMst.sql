Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbDocumentMst
Values(@ID,'EB','ELECTRICITY BILL','A');
END
GO

Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbDocumentMst
Values(@ID,'PB','PHONE BILL','A');
END
GO

Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbDocumentMst
Values(@ID,'DL','DRIVING LICENSE','A');
END
GO

Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbDocumentMst
Values(@ID,'EC','ELECTION CARD','A');
END
GO

Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbDocumentMst
Values(@ID,'PC','PAN CARD','A');
END
GO

Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbDocumentMst
Values(@ID,'PP','PASSPORT','A');
END
GO

Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbDocumentMst
Values(@ID,'PCF','PARENT CONSENT FORM','A');
END
GO

Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbDocumentMst
Values(@ID,'AC','ADHAR CARD','A');
END
GO

Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbDocumentMst
Values(@ID,'BNKST','BANK STATEMENT','A');
END
GO

Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbDocumentMst
Values(@ID,'OI','OCCUPATION ID','A');
END
GO



CREATE TABLE [dbo].[tbDocumentMst](
	[DocID] [uniqueidentifier] DEFAULT NEWID() NOT NULL,
	[DocCode] [varchar](20) NOT NULL,
	[DocName] [varchar](100) NULL,
	[DocStatus] [char](1) NULL CONSTRAINT [df_DocStatus]  DEFAULT ('A'),
PRIMARY KEY CLUSTERED 
(
	[DocCode] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

