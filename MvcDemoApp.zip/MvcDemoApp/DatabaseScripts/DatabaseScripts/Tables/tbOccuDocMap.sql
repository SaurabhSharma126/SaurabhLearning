CREATE TABLE tbOccuDocMap(
ID uniqueidentifier,
OccuCd varchar(10),
DocCD varchar(10),
Mandatory char
);