CREATE TABLE [dbo].[tbOccupationMst](
	[OccupID] [uniqueidentifier] NOT NULL DEFAULT (newid()),
	[OccupCode] [varchar](10) NULL,
	[OcuupName] [varchar](100) NULL,
 CONSTRAINT [pk_OccupID] PRIMARY KEY CLUSTERED 
(
	[OccupID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO



Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbOccupationMst
Values(@ID,'GE','GOVERNMENT');
END
GO

Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbOccupationMst
Values(@ID,'PE','PRIVATE');
END
GO

Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbOccupationMst
Values(@ID,'SE','SELF');
END
GO

Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbOccupationMst
Values(@ID,'SD','STUDENT');
END
GO

Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbOccupationMst
Values(@ID,'GT','GRADUATE');
END
GO

Declare
@ID uniqueIdentifier
SET @ID = NEWID();
begin
insert into tbOccupationMst
Values(@ID,'FR','FOREIGNER');
END
GO