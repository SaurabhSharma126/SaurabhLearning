﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;
using MvcDemoApp.Controllers;
using MvcDemoApp.DatabaseLayer;

namespace MvcDemoApp.Models
{
    public class DocumentSelector
    {
        public string OccupationCd;
        public string OccuCode;
        public string DocName;
        public string OccuName;
        public List<DocumentSelector> GridMap { get; set; }

        public string OccuaptionCode
        {
            get { return OccuCode; }
            set { OccuCode = value; }
        }

        public string DocumentName
        {
            get { return DocName; }
            set { DocName = value; }
        }

        public string OccupationName
        {
            get { return OccuName; }
            set { OccuName = value; }
        }
       
        public List<String> getddOccuCode()
        {
            return DatabaseCon.GetOccupCode();
        }

        public void UploadFileInsert(string UserName, string ImageName, string DocCode, string Path)
        {
            DatabaseCon.InsertUploadFile(UserName, ImageName, DocCode, Path);
        }
    }
}