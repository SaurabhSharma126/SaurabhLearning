﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using MvcDemoApp.DatabaseLayer;
using System.ComponentModel.DataAnnotations;

namespace MvcDemoApp.Models
{
    public class EmployeeLogin
    {
        [Required]
        public string _Username = string.Empty;
        [Required]
        public string _password = string.Empty;
        public string _message = string.Empty;

        public string Username
        {
            get { return _Username; }
            set { _Username = value; }
        }

        public string Password
        {
            get { return _password; }
            set { _password = value; }
        }

        public string Message
        {
            get { return _message; }
            set { _message = value; }
        }

        public void ValidateLogin(string Username, string Password)
        {
            DatabaseCon.LoginValidate(Username, Password);
        }
    }
}