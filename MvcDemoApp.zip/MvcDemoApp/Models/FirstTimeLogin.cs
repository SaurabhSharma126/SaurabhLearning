﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace MvcDemoApp.Models
{
    public class FirstTimeLogin
    {
        [Display(Name="First Name")]
        [Required]
        public string FirstName { get; set; }

        [Display(Name = "Last Name")]
        [Required]
        public string LastName { get; set; }
        
        [Display(Name = "Date of Birth")]
        [Required]
        public DateTime DateOfBirth { get; set; }

        [Display(Name = "New Password")]
        [Required]
        public string NewPassword { get; set; }
        
        [Display(Name = "Confirm Password")]
        [Required]
        public string ConfirmPassword { get; set; }
        
        [Display(Name = "Security Question 1")]
        [Required]
        public string SecurityQuestion_1 { get; set; }
        
        [Display(Name = "Security Question 2")]
        [Required]
        public string SecurityQuestion_2 { get; set; }
        
        public static void FetchDetais(string UserName)
        {
            DatabaseLayer.DatabaseCon.FetchLoginDetails(UserName);
        }
    }
}